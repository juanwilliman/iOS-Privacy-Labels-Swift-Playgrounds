import PlaygroundSupport
import SwiftUI

// Main View
struct MainView: View {
    var body: some View {
        ZStack {
            PrivacyLabel()
        }
    }
}

PlaygroundPage.current.setLiveView(MainView())
