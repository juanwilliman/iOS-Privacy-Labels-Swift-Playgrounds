import SwiftUI

public struct PrivacyLabel: View {
    @Environment(\.colorScheme) var colorScheme
    public init(){}
    public var body: some View {
        ZStack {
            Card()
            ZStack {
                VStack {
                    Title()
                    PurchasesAndLocation()
                    ContactAndUser()
                    SearchAndUsage()
                }
            }
            .frame(width: 300, height: 230)
        }
    }
}

struct Card: View {
    @Environment(\.colorScheme) var colorScheme
    var body: some View {
        Rectangle()
            .frame(width: 300, height: 230)
            .foregroundColor(colorScheme == .light ? .white : .black)
            .cornerRadius(15)
            .shadow(color: Color(.displayP3, red: 0, green: 0, blue: 0, opacity: 0.2), radius: 10, x: 0, y: 10)
    }
}

struct Title: View {
    var body: some View {
        VStack {
            Image(systemName: "person.circle")
                .resizable()
                .foregroundColor(.blue)
                .frame(width: 32, height: 32)
            Text("Data Linked to You")
                .bold()
                .font(.system(size: 17))
            Text("The following data may be collected and\nlinked to your identity:")
                .font(.system(size: 13))
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .font(.system(size: 13))
                .padding(.top, 1)
        }
    }
}

struct PurchasesAndLocation: View {
    var body: some View {
        HStack {
            HStack {
                Image(systemName: "bag.fill")
                Text("Purchases")
                    .font(.system(size: 12))
            }
            .padding(. leading, 22)
            Spacer()
            HStack {
                Image(systemName: "location.fill")
                Text("Location")
                    .font(.system(size: 12))
            }
            .padding(.trailing, 65)
        }
        .padding(.top, 5)
    }
}

struct ContactAndUser: View {
    var body: some View {
        HStack {
            HStack {
                Image(systemName: "info.circle.fill")
                Text("Contact Info")
                    .font(.system(size: 12))
            }
            .padding(. leading, 22)
            Spacer()
            HStack {
                Image(systemName: "photo.fill.on.rectangle.fill")
                Text("User Content")
                    .font(.system(size: 12))
            }
            .padding(.trailing, 38)
        }
        .padding(.top, 1)
    }
}

struct SearchAndUsage: View {
    var body: some View {
        HStack {
            HStack {
                Image(systemName: "magnifyingglass.circle.fill")
                Text("Search History")
                    .font(.system(size: 12))
            }
            .padding(. leading, 22)
            Spacer()
            HStack {
                Image(systemName: "chart.bar.fill")
                Text("Usage Data")
                    .font(.system(size: 12))
            }
            .padding(.trailing, 47)
        }
        .padding(.top, 1)
    }
}
